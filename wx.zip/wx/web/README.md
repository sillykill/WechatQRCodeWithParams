系统配置 
	1、jQuery 3.4.1
	2、element 2.13.0
	3、layer 3.1.1
	4、vue 2.6.10
	5、layui 2.5.6
	6、echarts 4.6.0

文件夹说明
	1、css			css样式
	2、data			存放json等数据
	3、img 			图片文件
	4、js           js文件
	5、lib          系统配置 其他框架文件
	6、pages        html页面
	
导航栏参数说明 
		1、"title": "控制台2",  				   导航栏标题
		2、"icon": "el-icon-setting",		   图标样式 使用element图标库 有数量限制不能自定义
		3、"href": "#",						   链接地址 为# 时不会跳转
		4、"id":"2",						   唯一标识id 暂时只能自定义，每个都需不一样
		5、"children"                          存放二级导航栏数组
	